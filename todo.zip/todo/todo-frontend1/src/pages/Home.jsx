// src/pages/Home.jsx
import React from 'react';
import Navbar from '../components/Navbar';
import './Home.css'; // Create this CSS file

const HomePage = ({ isLoggedIn }) => {
  return (
    <>
      <Navbar isLoggedIn={isLoggedIn} />
      <div className="main-content">
        <div className="welcome-section container-card">
          <h1>Welcome to Online To-Do List</h1>
          <p>Stay organized. Stay productive.</p>
        </div>
      </div>
    </>
  );
};

export default HomePage;
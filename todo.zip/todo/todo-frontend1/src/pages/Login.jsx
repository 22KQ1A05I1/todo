





// src/pages/Login.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';
import './Login.css';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const LoginPage = ({ onLogin, isLoggedIn }) => {
  const [formType, setFormType] = useState('login'); // 'login', 'signup', 'forgot'
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${API_BASE_URL}/auth/login`, {
        username,
        password,
      });

      if (response.status === 200) {
        // Store username and password (for basic auth) - IMPORTANT: INSECURE FOR PRODUCTION WITHOUT HTTPS
        // In a real app with JWT, you'd receive and store a JWT token here.
        localStorage.setItem('username', username); // Storing username
        localStorage.setItem('password', password); // Storing password (base64 encoded for auth header)

        const user = response.data; // Assuming your login returns the user object with ID
        localStorage.setItem('user', JSON.stringify(user)); // Store user details (for demo)

        alert('Login successful!');
        onLogin(); // Update parent state (sets isLoggedIn to true)
        navigate('/todo');
      } else {
        alert('Login failed. Please check your credentials.');
      }
    } catch (error) {
      console.error('Login error:', error);
      alert('Login failed. Please check your credentials or server status.');
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API_BASE_URL}/auth/signup`, {
        username: newUsername,
        email: newEmail,
        password: newPassword,
      });
      alert('Sign-up successful! Please login.');
      setFormType('login');
      // Clear signup fields
      setNewUsername('');
      setNewEmail('');
      setNewPassword('');
    } catch (error) {
      console.error('Signup error:', error);
      alert(error.response?.data || 'Sign-up failed. Username or email might be taken.');
    }
  };

  const handleResetPassword = (e) => {
    e.preventDefault();
    if (forgotEmail) {
      alert(`Reset link sent to ${forgotEmail}`);
      setFormType('login');
      setForgotEmail('');
    } else {
      alert("Please enter a valid email.");
    }
  };

  // If already logged in, redirect to tasks
  if (isLoggedIn) {
    navigate('/todo');
  }

  return (
    <>
      <Navbar isLoggedIn={isLoggedIn} />
      <div className="login-page-wrapper">
        <div className="container-card auth-container">
          {formType === 'login' && (
            <div id="loginForm">
              <h2>Login to TodoMate</h2>
              <form onSubmit={handleLogin}>
                <input
                  type="text"
                  placeholder="Username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
                <input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button type="submit">Login</button>
              </form>
              <button
                className="google-btn"
                onClick={() => alert('Google Login not implemented')}
              >
            <img src="https://img.icons8.com/color/48/000000/google-logo.png" alt="Google" />
               {/* <img src="" alt="Google" />  */}
                Login with Google
              </button>
              <span className="toggle-link" onClick={() => setFormType('signup')}>
                Don't have an account? Sign up
              </span>
              <span className="toggle-link" onClick={() => setFormType('forgot')}>
                Forgot Password?
              </span>
            </div>
          )}

          {formType === 'signup' && (
            <div id="signupForm">
              <h2>Create a New Account</h2>
              <form onSubmit={handleSignup}>
                <input
                  type="text"
                  placeholder="New Username"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  required
                />
                <input
                  type="email"
                  placeholder="Email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  required
                />
                <input
                  type="password"
                  placeholder="Password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
                <button type="submit">Sign Up</button>
              </form>
              <span className="toggle-link" onClick={() => setFormType('login')}>
                Already have an account? Login
              </span>
            </div>
          )}

          {formType === 'forgot' && (
            <div id="forgotPasswordForm">
              <h2>Reset Password</h2>
              <form onSubmit={handleResetPassword}>
                <input
                  type="email"
                  placeholder="Enter your email"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  required
                />
                <button type="submit">Send Reset Link</button>
              </form>
              <span className="toggle-link" onClick={() => setFormType('login')}>
                Back to Login
              </span>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default LoginPage;






// src/pages/Todo.jsx
import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import axios from 'axios';
import './Todo.css';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const TodoPage = ({ onLogout, isLoggedIn }) => {
  const [tasks, setTasks] = useState([]);
  const [taskInput, setTaskInput] = useState('');
  const [filter, setFilter] = useState('all');
  const [userId, setUserId] = useState(null); // Still useful for initial user info display if needed
  const [authHeader, setAuthHeader] = useState('');

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      setUserId(user.id); // Keep userId for display or other client-side logic

      const username = localStorage.getItem('username');
      const password = localStorage.getItem('password');
      if (username && password) {
        const base64Credentials = btoa(`${username}:${password}`);
        setAuthHeader(`Basic ${base64Credentials}`);
        console.log("Auth header set:", `Basic ${base64Credentials}`);
      } else {
        console.warn("Username or password not found in localStorage. Logging out.");
        onLogout();
      }
    } else {
      console.warn("No user found in localStorage. Logging out.");
      onLogout();
    }
  }, []);

  useEffect(() => {
    // Only fetch if authHeader is ready and user is considered logged in
    if (authHeader && isLoggedIn) {
      fetchTasks();
    } else if (isLoggedIn && !authHeader) {
      console.log("Waiting for authHeader to be set before fetching tasks...");
    }
  }, [filter, authHeader, isLoggedIn]); // userId is no longer a dependency for fetching since backend derives it

  const fetchTasks = async () => {
    console.log("Attempting to fetch tasks for current user with filter:", filter);
    try {
      // Changed endpoint from /tasks/user/{userId} to /tasks (backend now derives userId)
      const response = await axios.get(`${API_BASE_URL}/tasks`, {
        params: { filter: filter === 'all' ? undefined : filter },
        headers: {
          'Authorization': authHeader,
        },
      });
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
      if (error.response && error.response.status === 401) {
        alert('Your session has expired or you are unauthorized. Please log in again.');
        onLogout();
      }
    }
  };

  const addTask = async () => {
    if (taskInput.trim() === '') return;
    console.log("Attempting to add task for current user with description:", taskInput);
    try {
      // Changed endpoint from /tasks/user/{userId} to /tasks
      const response = await axios.post(`${API_BASE_URL}/tasks`, {
        description: taskInput,
      }, {
        headers: {
          'Authorization': authHeader,
        },
      });
      setTasks([...tasks, response.data]);
      setTaskInput('');
      fetchTasks();
    } catch (error) {
      console.error('Error adding task:', error);
      if (error.response && error.response.status === 401) {
        alert('Your session has expired or you are unauthorized. Please log in again.');
        onLogout();
      }
    }
  };

  const toggleTask = async (taskId, completed) => {
    console.log("Attempting to toggle task ID:", taskId, "completed status to:", !completed);
    try {
      await axios.put(`${API_BASE_URL}/tasks/${taskId}`, {
        completed: !completed,
      }, {
        headers: {
          'Authorization': authHeader,
        },
      });
      fetchTasks();
    } catch (error) {
      console.error('Error toggling task:', error);
      if (error.response && error.response.status === 401) {
        alert('Your session has expired or you are unauthorized. Please log in again.');
        onLogout();
      } else if (error.response && error.response.status === 403) {
        alert('You are not authorized to update this task.');
      } else if (error.response && error.response.status === 404) {
        alert('Task not found.');
      }
    }
  };

  const deleteTask = async (taskId) => {
    console.log("Attempting to delete task ID:", taskId);
    try {
      await axios.delete(`${API_BASE_URL}/tasks/${taskId}`, {
        headers: {
          'Authorization': authHeader,
        },
      });
      fetchTasks();
    } catch (error) {
      console.error('Error deleting task:', error);
      if (error.response && error.response.status === 401) {
        alert('Your session has expired or you are unauthorized. Please log in again.');
        onLogout();
      } else if (error.response && error.response.status === 403) {
        alert('You are not authorized to delete this task.');
      } else if (error.response && error.response.status === 404) {
        alert('Task not found.');
      }
    }
  };

  return (
    <>
      <Navbar isLoggedIn={isLoggedIn} onLogout={onLogout} />
      <div className="wrapper">
        <div className="container-card todo-container">
          <h2>Your Online To-Do List</h2>
          <div className="add-task-section">
            <input
              type="text"
              id="taskInput"
              placeholder="Enter a new task"
              value={taskInput}
              onChange={(e) => setTaskInput(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter') addTask();
              }}
            />
            <button onClick={addTask}>Add Task</button>
          </div>
          <div className="filters">
            <button onClick={() => setFilter('all')} className={filter === 'all' ? 'active-filter' : ''}>All</button>
            <button onClick={() => setFilter('completed')} className={filter === 'completed' ? 'active-filter' : ''}>Completed</button>
            <button onClick={() => setFilter('pending')} className={filter === 'pending' ? 'active-filter' : ''}>Pending</button>
          </div>
          <ul id="taskList">
            {tasks.map((task) => (
              <li key={task.id} className={task.completed ? 'completed' : ''}>
                <span onClick={() => toggleTask(task.id, task.completed)}>
                  {task.description}
                </span>
                <button className="delete-btn" onClick={() => deleteTask(task.id)}>
                  🗑️
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </>
  );
};

export default TodoPage;

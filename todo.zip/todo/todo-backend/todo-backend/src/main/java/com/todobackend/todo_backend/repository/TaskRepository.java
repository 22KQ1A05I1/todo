

// src/main/java/com/todobackend/todo_backend/repository/TaskRepository.java
package com.todobackend.todo_backend.repository;

import com.todobackend.todo_backend.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for Task entities.
 * Extends JpaRepository to provide standard CRUD (Create, Read, Update, Delete) operations.
 * Also defines custom query methods for filtering tasks by user and completion status.
 */
@Repository // Marks this interface as a Spring Data JPA repository
public interface TaskRepository extends JpaRepository<Task, Long> {

    /**
     * Finds all tasks associated with a specific user ID.
     * Spring Data JPA automatically generates the query based on the method name.
     * @param userId The ID of the user whose tasks are to be retrieved.
     * @return A list of tasks belonging to the specified user.
     */
    List<Task> findByUserId(Long userId);

    /**
     * Finds tasks for a specific user ID, filtered by their completion status.
     * @param userId The ID of the user.
     * @param completed A boolean indicating whether to retrieve completed (true) or pending (false) tasks.
     * @return A list of tasks matching the user ID and completion status.
     */
    List<Task> findByUserIdAndCompleted(Long userId, boolean completed);
}


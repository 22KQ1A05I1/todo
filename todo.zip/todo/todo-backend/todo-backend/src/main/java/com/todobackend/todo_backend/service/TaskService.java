

// src/main/java/com/todobackend/todo_backend/service/TaskService.java
package com.todobackend.todo_backend.service;

import com.todobackend.todo_backend.model.Task;
import com.todobackend.todo_backend.model.User;
import com.todobackend.todo_backend.repository.TaskRepository;
import com.todobackend.todo_backend.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    public TaskService(TaskRepository taskRepository, UserRepository userRepository) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
    }

    // --- CRUD Operations ---

    /**
     * Creates a new task for a specified user.
     * @param userId The ID of the user who owns this task.
     * @param description The description of the task.
     * @return The newly created Task object.
     * @throws RuntimeException if the user with the given ID is not found.
     */
    public Task createTask(Long userId, String description) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            throw new RuntimeException("User not found with ID: " + userId);
        }

        Task task = new Task();
        task.setDescription(description);
        task.setCompleted(false);
        task.setUser(userOptional.get());
        return taskRepository.save(task);
    }

    /**
     * Retrieves tasks for a specific user, optionally filtered by completion status.
     * @param userId The ID of the user whose tasks are to be retrieved.
     * @param filter A string ("all", "completed", "pending") to filter tasks. Case-insensitive.
     * @return A list of tasks matching the criteria.
     */
    public List<Task> getTasksByUser(Long userId, String filter) {
        if (filter != null) {
            if ("completed".equalsIgnoreCase(filter)) {
                return taskRepository.findByUserIdAndCompleted(userId, true);
            } else if ("pending".equalsIgnoreCase(filter)) {
                return taskRepository.findByUserIdAndCompleted(userId, false);
            }
        }
        return taskRepository.findByUserId(userId);
    }

    /**
     * Retrieves a single task by its ID.
     * @param taskId The ID of the task to retrieve.
     * @return An Optional containing the Task if found, or empty if not found.
     */
    public Optional<Task> getTaskById(Long taskId) {
        return taskRepository.findById(taskId);
    }

    /**
     * Updates an existing task's description and/or completion status.
     * Ensures the task belongs to the specified user.
     * @param userId The ID of the user attempting to update the task.
     * @param taskId The ID of the task to update.
     * @param description The new description for the task (can be null if not updating).
     * @param completed The new completion status for the task (can be null if not updating).
     * @return The updated Task object.
     * @throws RuntimeException if the task is not found or does not belong to the user.
     */
    public Task updateTask(Long userId, Long taskId, String description, Boolean completed) {
        // Find the existing task and ensure it belongs to the user
        Optional<Task> existingTaskOptional = taskRepository.findById(taskId);
        if (existingTaskOptional.isEmpty()) {
            throw new RuntimeException("Task not found with ID: " + taskId);
        }
        Task existingTask = existingTaskOptional.get();

        // Security check: Ensure the task belongs to the authenticated user
        if (!existingTask.getUser().getId().equals(userId)) {
            throw new RuntimeException("Access denied: Task does not belong to user with ID: " + userId);
        }

        // Update properties if provided
        if (description != null && !description.trim().isEmpty()) {
            existingTask.setDescription(description);
        }
        if (completed != null) {
            existingTask.setCompleted(completed);
        }
        return taskRepository.save(existingTask);
    }

    /**
     * Deletes a task by its ID, ensuring it belongs to the specified user.
     * @param userId The ID of the user attempting to delete the task.
     * @param taskId The ID of the task to delete.
     * @throws RuntimeException if the task is not found or does not belong to the user.
     */
    public void deleteTask(Long userId, Long taskId) {
        // Find the task and ensure it belongs to the user before deleting
        Optional<Task> taskOptional = taskRepository.findById(taskId);
        if (taskOptional.isEmpty()) {
            throw new RuntimeException("Task not found with ID: " + taskId);
        }
        Task taskToDelete = taskOptional.get();

        // Security check: Ensure the task belongs to the authenticated user
        if (!taskToDelete.getUser().getId().equals(userId)) {
            throw new RuntimeException("Access denied: Task does not belong to user with ID: " + userId);
        }

        taskRepository.deleteById(taskId);
    }
}

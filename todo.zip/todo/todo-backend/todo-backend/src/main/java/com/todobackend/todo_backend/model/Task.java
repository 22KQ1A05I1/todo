

// src/main/java/com/todobackend/todo_backend/model/Task.java
package com.todobackend.todo_backend.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Represents a Task entity in the database.
 * Each task belongs to a specific User.
 */
@Entity
@Table(name = "tasks") // Maps this entity to the 'tasks' table in the database
@Data // Lombok annotation to generate getters, setters, toString, equals, and hashCode
@NoArgsConstructor // Lombok annotation to generate a no-argument constructor
@AllArgsConstructor // Lombok annotation to generate an all-argument constructor
public class Task {
    @Id // Marks the 'id' field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Configures auto-incrementing ID
    private Long id;

    @Column(nullable = false) // Ensures the 'description' column cannot be null
    private String description;

    @Column(nullable = false) // Ensures the 'completed' column cannot be null (default to false)
    private boolean completed = false; // Default value for new tasks

    // Many-to-One relationship with the User entity.
    // Many tasks can belong to one user.
    @ManyToOne(fetch = FetchType.LAZY) // Lazy loading for performance (user data fetched only when needed)
    @JoinColumn(name = "user_id", nullable = false) // Specifies the foreign key column 'user_id'
    private User user; // The User to whom this task belongs
}



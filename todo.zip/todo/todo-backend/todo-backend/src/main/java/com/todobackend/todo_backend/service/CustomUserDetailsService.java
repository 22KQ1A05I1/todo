package com.todobackend.todo_backend.service;


import com.todobackend.todo_backend.model.User;
import com.todobackend.todo_backend.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.security.core.authority.SimpleGrantedAuthority; // For roles

import java.util.Collections; // For roles

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public CustomUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Loads user-specific data from the database based on the username.
     * This method is called by Spring Security's authentication providers.
     *
     * @param username The username to retrieve user details for.
     * @return A UserDetails object representing the authenticated user.
     * @throws UsernameNotFoundException if the user cannot be found.
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Find the user in your database
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        // Build Spring Security's UserDetails object.
        // For simplicity, we're giving all users a "ROLE_USER" authority.
        // In a real application, you'd fetch roles from the database if applicable.
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(), // The hashed password from the database
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")) // Assign a default role
        );
    }
}

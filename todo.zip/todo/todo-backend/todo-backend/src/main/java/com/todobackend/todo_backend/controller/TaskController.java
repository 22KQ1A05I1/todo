


// src/main/java/com/todobackend/todo_backend/controller/TaskController.java
package com.todobackend.todo_backend.controller;

import com.todobackend.todo_backend.model.Task;
import com.todobackend.todo_backend.service.TaskService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication; // Import Authentication
import org.springframework.security.core.context.SecurityContextHolder; // Import SecurityContextHolder
import org.springframework.security.core.userdetails.UserDetails; // Import UserDetails
import com.todobackend.todo_backend.repository.UserRepository; // Import UserRepository to get actual User object
import com.todobackend.todo_backend.model.User; // Import User model

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;
    private final UserRepository userRepository; // Inject UserRepository to find actual User by username

    public TaskController(TaskService taskService, UserRepository userRepository) {
        this.taskService = taskService;
        this.userRepository = userRepository;
    }

    // Helper method to get the current authenticated user's ID
    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User is not authenticated.");
        }
        // Assuming your UserDetails object contains the username (which it does with CustomUserDetailsService)
        String username = ((UserDetails) authentication.getPrincipal()).getUsername();

        // Fetch the User entity from the database using the username
        User currentUser = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Authenticated user not found in DB!"));
        return currentUser.getId();
    }


    /**
     * Creates a new task for a specified user.
     * POST /api/tasks
     * Request body: {"description": "Task description"}
     * The userId will be derived from the authenticated user.
     */
    @PostMapping
    public ResponseEntity<Task> createTask(@RequestBody Map<String, String> payload) {
        String description = payload.get("description");
        if (description == null || description.trim().isEmpty()) {
            return ResponseEntity.badRequest().body(null);
        }
        try {
            Long userId = getCurrentUserId(); // Get ID of the currently authenticated user
            Task newTask = taskService.createTask(userId, description);
            return ResponseEntity.status(HttpStatus.CREATED).body(newTask);
        } catch (RuntimeException e) {
            System.err.println("Error creating task: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // Use 400 for generic create error
        }
    }

    /**
     * Retrieves tasks for the current authenticated user, with optional filtering.
     * GET /api/tasks?filter=all|completed|pending
     * The userId will be derived from the authenticated user.
     */
    @GetMapping
    public ResponseEntity<List<Task>> getTasksForCurrentUser(@RequestParam(required = false) String filter) {
        try {
            Long userId = getCurrentUserId(); // Get ID of the currently authenticated user
            List<Task> tasks = taskService.getTasksByUser(userId, filter);
            return ResponseEntity.ok(tasks);
        } catch (RuntimeException e) {
            System.err.println("Error fetching tasks for current user: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build(); // 401 if user not authenticated
        }
    }

    /**
     * Updates an existing task by its ID.
     * PUT /api/tasks/{taskId}
     * Request body: {"description": "New description", "completed": true} (fields are optional)
     * Ensures the task belongs to the authenticated user.
     */
    @PutMapping("/{taskId}")
    public ResponseEntity<Task> updateTask(@PathVariable Long taskId, @RequestBody Map<String, Object> updates) {
        String description = (String) updates.get("description");
        Boolean completed = (Boolean) updates.get("completed");

        try {
            Long userId = getCurrentUserId(); // Get ID of the currently authenticated user
            Task updatedTask = taskService.updateTask(userId, taskId, description, completed); // Pass userId to service
            return ResponseEntity.ok(updatedTask);
        } catch (RuntimeException e) {
            System.err.println("Error updating task with ID " + taskId + ": " + e.getMessage());
            if (e.getMessage().contains("Task not found")) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            } else if (e.getMessage().contains("Access denied")) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null); // 403 Forbidden
            }
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); // Generic 500
        }
    }

    /**
     * Deletes a task by its ID.
     * DELETE /api/tasks/{taskId}
     * Ensures the task belongs to the authenticated user.
     */
    @DeleteMapping("/{taskId}")
    public ResponseEntity<Void> deleteTask(@PathVariable Long taskId) {
        try {
            Long userId = getCurrentUserId(); // Get ID of the currently authenticated user
            taskService.deleteTask(userId, taskId); // Pass userId to service
            return ResponseEntity.noContent().build(); // 204 No Content for successful deletion
        } catch (RuntimeException e) {
            System.err.println("Error deleting task with ID " + taskId + ": " + e.getMessage());
            if (e.getMessage().contains("Task not found")) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // 404 Not Found
            } else if (e.getMessage().contains("Access denied")) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build(); // 403 Forbidden
            }
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // Generic 500
        }
    }
}
